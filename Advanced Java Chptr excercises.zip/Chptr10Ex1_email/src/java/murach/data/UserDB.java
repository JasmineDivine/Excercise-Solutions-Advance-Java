package murach.data;

import murach.business.User;

public class UserDB {

    public static long insert(User user) {
        // TODO: Add code that adds the user to the database
        // NOTE: This is shown in chapters 11-13
        return 0;
    }
}
